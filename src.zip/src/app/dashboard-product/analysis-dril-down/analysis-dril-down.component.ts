import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-analysis-dril-down',
  templateUrl: './analysis-dril-down.component.html',
  styleUrls: ['./analysis-dril-down.component.scss']
})
export class AnalysisDrilDownComponent implements OnInit {
  folders = [
    {
      id: "1",
      name: 'Store Visit',

    },
    {
      id: "2",
      name: 'Positive Rate Plan Change',

    },
    {
      id: "3",
      name: 'Positive Support Resolution',

    }
  ];
notes = [
    {
      id: "1",
      name: 'Bill Roaming Charges',
    },
    {
      id: "2",
      name: 'Unresolved Support Issue',
    },
    {
      id: "3",
      name: 'Multiple Calls To Customer Care',
    },
    {
      id: "4",
      name: 'Customer Care Rule',
    },
    {
      id: "5",
      name: 'Support Escalation',
    }
  ];
  negetiiveUSers = [
    {
      id: "1",
      name: 'rjx@gmail.com',
    },
    {
      id: "2",
      name: 'pyk@yahoo..com',
    },
    {
      id: "3",
      name: 'mkd@you.com',
    },
    {
      id: "4",
      name: 'jack@abc.com',
    },
    {
      id: "5",
      name: 'fyk@tcs.com',
    }
  ];

positiiveUSers = [
    {
      id: "1",
      name: 'rjx@gmail.com',
    },
    {
      id: "2",
      name: 'pyk@yahoo..com',
    },
    {
      id: "3",
      name: 'mkd@you.com',
    },
    {
      id: "4",
      name: 'jack@abc.com',
    },
    {
      id: "5",
      name: 'fyk@tcs.com',
    }
  ];
  jsonData: any = [
    { 'x': 'Nov 11', 'y': 69 },
    { 'x': 'Dec 11', 'y': 47 },
    { 'x': 'Jan 12', 'y': 63 },
    { 'x': 'Feb 12', 'y': 82 },
    { 'x': 'Mar 12 ', 'y': 52 },
    { 'x': 'April 12', 'y': 89 },];
  constructor() { }

  ngOnInit() {
  }

}
