import { Component, AfterViewInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { TdLoadingService } from '@covalent/core';
import {Router } from '@angular/router';
import { TdDataTableSortingOrder, TdDataTableService, ITdDataTableSortChangeEvent, ITdDataTableColumn  } from '@covalent/data-table';
import {NavigationService} from '../../../services';


const NUMBER_FORMAT: any = (v: {value: number}) => v.value;
const DECIMAL_FORMAT: any = (v: {value: number}) => v.value.toFixed(2);


@Component({
  selector: 'app-analysis-table',
  templateUrl: './analysis-table.component.html',
  styleUrls: ['./analysis-table.component.scss']
})
export class AnalysisTableComponent implements AfterViewInit {


  columns: ITdDataTableColumn[] = [
{ name: 'name',  label: 'ID' },
    { name: 'type', label: 'Name' },
    { name: 'usage', label: 'Data Source' },
    { name: 'users', label: 'Start Time'},
    { name: 'load', label: 'End Time'},
    { name: 'time', label: 'Run Time'},
    
  ];



  title="User Session";

  data: any[] = [
      {
        'name': 63,
        'type': 'Standard Scoring Run',
        'usage': 'CSI Telco Data',
        'users': '2016-04-05 14:21:33',
        'load': '2016-04-05 14:23:05',
        'time': '00:01:34',
        
       }, {
        'name': 62,
        'type': 'Standard Scoring Run',
        'usage': 'CSI Telco Data',
        'users': '2016-04-05 14:21:33',
        'load': '2016-04-05 14:23:05',
        'time': '00:01:34',
      
      }, {
        'name': 61,
        'type': '09/01/2017  9:30 AM',
        'usage': 'CSI Telco Data',
        'users': '2016-04-05 14:21:33',
        'load': '2016-04-05 14:23:05',
        'time': '00:01:34',
        }, {
        'name': 60,
        'type': '09/01/2017  9:30 AM',
        'usage': 'CSI Telco Data',
        'users': '2016-04-05 14:21:33',
        'load': '2016-04-05 14:23:05',
        'time': '00:01:34',
       }, {
        'name': 59,
        'type': '09/01/2017  9:30 AM',
        'usage': 'CSI Telco Data',
        'users': '2016-04-05 14:21:33',
        'load': '2016-04-05 14:23:05',
        'time': '00:01:34',
      }
    ];



filteredData: any[] = this.data;
  filteredTotal: number = this.data.length;
  searchTerm: string = '';
  fromRow: number = 1;
  currentPage: number = 1;
  pageSize: number = 5;
  sortBy: string = 'name';
  sortOrder: TdDataTableSortingOrder = TdDataTableSortingOrder.Descending;




ngAfterViewInit(): void {
    this._titleService.setTitle( 'usersessions' );
    
  }

 constructor(private _router: Router, private _loadingService:TdLoadingService,  private _titleService: Title,
              private _dataTableService: TdDataTableService, private _navigationService:NavigationService, private _route:Router) {
                this._navigationService.storePath(this.title,this._route.url);
               }

  

}
