import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-analysis',
  templateUrl: './create-analysis.component.html',
  styleUrls: ['./create-analysis.component.scss']
})
export class CreateAnalysisComponent implements OnInit {

  selectedValue: string;
foods: any[] = [
  {value: 'steak-0', viewValue: 'Selected Rule'},
  {value: 'pizza-1', viewValue: 'Activation'},
  
];


todos: Object[] = [{
      finished: false,
      name: 'Deselect All',
    }, {
      finished: true,
      name: 'Store visit',
    }, {
      finished: true,
      name: 'Activation',
    }, {
      finished: true,
      name: 'Bill Roaming Charges',
    }, {
      finished: true,
      name: 'Churn',
    }, {
      finished: true,
      name: 'Multiple Calls To Customer Care',
    },
    {
      finished: true,
      name: 'Customer Care Value',
    },
    {
      finished: true,
      name: 'Multiple Rate Plan Change',
    },
  ];



  constructor() { }

  ngOnInit() {
  }

}
