
import { Component, AfterViewInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { TdLoadingService } from '@covalent/core';
import {Router } from '@angular/router';
import { TdDataTableSortingOrder, TdDataTableService, ITdDataTableSortChangeEvent, ITdDataTableColumn  } from '@covalent/data-table';
import {NavigationService} from '../../../services';


@Component({
  selector: 'app-customer-history',
  templateUrl: './customer-history.component.html',
  styleUrls: ['./customer-history.component.scss']
})
export class CustomerHistoryComponent implements AfterViewInit {


   columns: ITdDataTableColumn[] = [
{ name: 'name',  label: '' },
    { name: 'type', label: 'Event' },
    { name: 'usage', label: 'Category' },
    { name: 'users', label: 'Amount'},
    { name: 'load', label: 'Duration'},
    { name: 'time', label: ' Date'},
     { name: 'type', label: 'Event' },
    { name: 'usage', label: 'Category' },
    { name: 'users', label: 'Amount'},
    { name: 'load', label: 'Duration'},
    { name: 'time', label: ' Date'},
    
  ];



  title="User Session";

  data: any[] = [
      {
        'name': 63,
        'type': 'Standard Scoring Run',
        'usage': 'CSI Telco Data',
        'users': '2016-04-05 14:21:33',
        'load': '2016-04-05 14:23:05',
        'time': '00:01:34',
        
       }, {
        'name': 62,
        'type': 'Standard Scoring Run',
        'usage': 'CSI Telco Data',
        'users': '2016-04-05 14:21:33',
        'load': '2016-04-05 14:23:05',
        'time': '00:01:34',
      
      }, {
        'name': 61,
        'type': '09/01/2017  9:30 AM',
        'usage': 'CSI Telco Data',
        'users': '2016-04-05 14:21:33',
        'load': '2016-04-05 14:23:05',
        'time': '00:01:34',
        }, {
        'name': 60,
        'type': '09/01/2017  9:30 AM',
        'usage': 'CSI Telco Data',
        'users': '2016-04-05 14:21:33',
        'load': '2016-04-05 14:23:05',
        'time': '00:01:34',
       }, {
        'name': 59,
        'type': '09/01/2017  9:30 AM',
        'usage': 'CSI Telco Data',
        'users': '2016-04-05 14:21:33',
        'load': '2016-04-05 14:23:05',
        'time': '00:01:34',
      }
    ];



   constructor(private _router: Router, private _loadingService:TdLoadingService,  private _titleService: Title,
              private _dataTableService: TdDataTableService, private _navigationService:NavigationService, private _route:Router) {
                this._navigationService.storePath(this.title,this._route.url);
               }

 ngAfterViewInit(): void {
    this._titleService.setTitle( 'usersessions' );
    
  }
}
