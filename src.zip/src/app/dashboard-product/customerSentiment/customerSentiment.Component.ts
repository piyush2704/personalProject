import { Component,AfterViewInit } from '@angular/core';
import {Router} from '@angular/router' ;
import { TdLoadingService } from '@covalent/core';

import { ItemsService, UsersService ,NavigationService} from '../../../services';


@Component({
    selector: 'customer-centiment',
  templateUrl: 'customerSentiment.component.html',
  styleUrls: ['customerSentiment.component.scss'],
   viewProviders: [ ItemsService, UsersService ],

})



export class customerSentiment implements AfterViewInit {
   
  constructor(private _navigationService:NavigationService,private _route:Router) {
    
 }
  ngAfterViewInit(): void {
   this._navigationService.storePath("CSI",this._route.url);
  
  }
  check:boolean =true;
  flexvalue=60;
  analysis:boolean=true;
  rules:boolean=false;
AnalysisCheck()
{
  this.check=true;
  this.flexvalue=60;
  this.analysis=true;
  this.rules=false;
}
Rules()
{
  this.check=false;
  this.flexvalue=30;
 this.analysis=false;
  this.rules=true;
}

createAnalysis(){
  this._route.navigate(['main/createAnalysis']);
}
}