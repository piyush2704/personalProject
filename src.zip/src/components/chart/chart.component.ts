import { Component } from '@angular/core';

@Component({
  selector: 'chart-component',
  templateUrl: 'chart.component.html',
  styleUrls: ['chart.component.scss'],
})
export class ChartComponent {

}
