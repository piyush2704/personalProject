export const MOCK_API: string = 'http://localhost:8080';
